Azure Pipelines Scripts
=======================

This directory contains scripts used for [testing ycmd on Azure
Pipelines](https://dev.azure.com/YouCompleteMe/YCM/_build?definitionId=2). They
should not normally be run by users.
