def NoException():
    pass


def RaiseException():
    raise Exception( 'Exception raised' )
