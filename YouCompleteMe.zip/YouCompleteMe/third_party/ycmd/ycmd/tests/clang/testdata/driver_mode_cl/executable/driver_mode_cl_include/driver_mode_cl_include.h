#ifndef DRIVER_MODE_CL_INCLUDE_H
#define DRIVER_MODE_CL_INCLUDE_H

void driver_mode_cl_include_func(void);
int driver_mode_cl_include_int;

#endif /* DRIVER_MODE_CL_INCLUDE_H */
