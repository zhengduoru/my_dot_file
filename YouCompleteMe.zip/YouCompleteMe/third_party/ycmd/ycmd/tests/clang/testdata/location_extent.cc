class Test {
  Test()// ignore comment
};

multiline_\
identifier

Test::Test() {
}
