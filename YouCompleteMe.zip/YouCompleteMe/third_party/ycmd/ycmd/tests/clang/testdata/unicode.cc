
int main( int argc, char ** argv )
{
  int id_with_å_unicode_chars = 10;
  struct MyStruct {
    int member_with_å_unicøde;
  } myå;

  myå.w
}

int another_main()
{
  struct MyStruct {
    /**
     * This method has unicøde in it
     */
    int member_with_å_unicøde;
  } myå;

  int a = myå.member_with_å_unicøde
}
