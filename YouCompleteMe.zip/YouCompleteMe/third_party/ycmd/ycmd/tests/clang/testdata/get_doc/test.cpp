#include "test.hpp"

int main() {
    test();
}
