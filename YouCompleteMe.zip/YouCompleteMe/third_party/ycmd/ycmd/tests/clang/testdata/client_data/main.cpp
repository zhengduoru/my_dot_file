struct Foo {
  int x;
};

int main()
{
  Foo foo;
  // The location after the dot is line 9, col 7
  foo.
}

