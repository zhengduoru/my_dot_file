def Settings( **kwargs ):
  return {
    'ls': {},
    'flags': [ '-I', 'test' ],
  }
