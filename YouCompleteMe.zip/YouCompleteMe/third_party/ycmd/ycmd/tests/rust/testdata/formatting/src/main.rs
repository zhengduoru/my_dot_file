fn unformatted_function(  param : bool) ->   bool
  { return param }

fn 
main()
                                {
        unformatted_function( false );
        let x = 1;
}
