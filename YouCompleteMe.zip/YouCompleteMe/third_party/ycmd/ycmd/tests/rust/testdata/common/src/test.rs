/// Be careful when using that function
pub fn create_universe() {}

pub struct Builder {}
impl Builder {
  /// Do not try at home
  fn build_rocket(&self) {}
  fn build_shuttle(&self) {}
}
