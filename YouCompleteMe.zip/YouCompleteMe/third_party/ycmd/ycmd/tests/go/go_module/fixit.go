package main
import ( "fmt" )
// Line must exist - bug in gopls?
