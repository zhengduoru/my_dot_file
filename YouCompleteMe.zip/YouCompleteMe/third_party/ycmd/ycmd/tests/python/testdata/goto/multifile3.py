my_integer = 1

def my_function():
    pass
