def some_function():
    return 123

class SomeClass():
    def __init__(self, *args, **kwargs):
        pass

    def SomeMethod(self, first_param, second_param):
        pass

some_integer = some_function()
some_class = SomeClass()
some_class.SomeMethod()

if condition:
    variable = 'test'
else:
    variable = some_function()
variable
