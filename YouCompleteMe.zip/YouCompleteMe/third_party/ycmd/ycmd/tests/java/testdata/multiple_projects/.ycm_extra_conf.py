def Settings( **kwargs ):
  return {
    'project_directory': './src'
  }
