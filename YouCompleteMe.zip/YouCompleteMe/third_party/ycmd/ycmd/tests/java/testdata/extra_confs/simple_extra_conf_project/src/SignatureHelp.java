
public class SignatureHelp
{
  public SignatureHelp( String signature ) {
    this.test( "test", "t" );
    this.test( 1, "2" );
    char [] data = new char[10];
    String.copyValueOf( data, 1, 2 );
    this.unique( 10.0 );
    String s = new String( data );
  }

  public void test( String s, String s1 ) {
    String.copyValueOf( 
  }
  public void test( int i, String s ) {
    SignatureHelp s = new SignatureHelp(
  }
  public void unique( double d ) {}
}
