# Comment
def Test_OneLine():
  """This is the one line output."""
  pass

def Test_MultiLine():
  """This is the one line output.
  This is second line."""
  pass

def Main():
  Test_OneLine()
  Test_MultiLine()


def Really_Long_Method( which, has, some, param, that, take, the, whole, line ):
  """Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum egestas libero urna, vel sagittis felis condimentum in. Nulla arcu eros, aliquet vel mollis vitae, semper eu ex. Donec posuere quam et ornare sagittis. Curabitur nunc ex, fringilla quis lorem sed, dignissim congue felis. Integer vestibulum ac elit vel blandit. Nam non dui urna. Integer eu semper massa. Nullam ac elit interdum, aliquet elit nec, porttitor orci. Duis tempus justo lorem, ac fringilla ante viverra egestas. Etiam eleifend enim ac libero dapibus, quis condimentum lectus tristique. Fusce feugiat, lorem et faucibus eleifend, ipsum nisi maximus justo, at consectetur ligula leo vitae justo."""
  # Really long one-line
  pass


def Really_Long_Method_2():
  """Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum egestas
  libero urna, vel sagittis felis condimentum in. Nulla arcu eros, aliquet vel
  mollis vitae, semper eu ex. Donec posuere quam et ornare sagittis. Curabitur
  nunc ex, fringilla quis lorem sed, dignissim congue felis. Integer vestibulum
  ac elit vel blandit. Nam non dui urna. Integer eu semper massa. Nullam ac elit
  interdum, aliquet elit nec, porttitor orci. Duis tempus justo lorem, ac
  fringilla ante viverra egestas. Etiam eleifend enim ac libero dapibus, quis
  condimentum lectus tristique. Fusce feugiat, lorem et faucibus eleifend, ipsum
  nisi maximus justo, at consectetur ligula leo vitae justo."""
  # Really long one para
  pass


def Moan():
  Really_Long_Method()
  Really_Long_Method_2()
